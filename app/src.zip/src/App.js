import React from 'react'
import Container from './components/container/Container';


export default function app() {
    return (
        <div>
            <Container />
        </div>
    )
}
