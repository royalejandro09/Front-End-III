import React from 'react'

function Options(props) {

    const { opcionA, opcionB, handleClick } = props;

    return (

        <div calssName='opciones'>

            <div className='opcion'>
                <button id='A' className='botones' onClick={handleClick}> A </button>

                <h2>{opcionA}</h2>

            </div>

            <div className='opcion'>
                <button id='B' className='botones' onClick={handleClick}> B </button>

                <h2>{opcionB}</h2>

            </div>

        </div>

    )

}

export default Options;